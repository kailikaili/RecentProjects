'use strict';

/* Controllers */

angular.module('angcardApp.controllers', [])

    .controller('OnlineCtrl', ['$scope', '$http', function ($scope, $http) {

        $scope.submit = function (form) {
            // 向服务请求 Google 的翻译结果
            $http.get('/google', {params: form}).success(function(result){
               // 将翻译的结果赋值给 r_google (result_google的缩写)
                $scope.r_google = result.translate_result; 
            });

            // 向服务请求 Bing 的翻译结果
            $http.get('/bing', {params: form}).success(function(result){
                $scope.r_bing = result.translate_result;
            });

            // 向服务请求 Youdao 的翻译结果
            $http.get('/youdao', {params: form}).success(function(result){
                $scope.r_youdao = result.translate_result;
            });

            // 向服务请求 Best 的翻译结果
            $http.get('/best', {params: form}).success(function(result){
                $scope.r_best = result.translate_result;
            });
        }

    }])


    .controller('OfflineCtrl', ['$scope', '$http', function ($scope, $http) {
        
        // 请求txtdb, 用于下拉菜单
        $http.get('/txtdb').success(function(result){
            $scope.txtdb = result.txtdb;
        });

        $scope.submit = function (form) {
            // 向服务请求 Google 的翻译结果
            $http.get('/google', {params: form}).success(function(result){
               // 将翻译的结果赋值给 r_google (result_google的缩写)
                $scope.r_google = result.translate_result; 
            });

            // 向服务请求 Bing 的翻译结果
            $http.get('/bing', {params: form}).success(function(result){
                $scope.r_bing = result.translate_result;
            });

            // 向服务请求 Youdao 的翻译结果
            $http.get('/youdao', {params: form}).success(function(result){
                $scope.r_youdao = result.translate_result;
            });

            // 向服务请求 Best 的翻译结果
            $http.get('/best', {params: form}).success(function(result){
                $scope.r_best = result.translate_result;
            });
        }

    }])


    .controller('Offline2Ctrl', ['$scope', '$http', function ($scope, $http) {
        
        // 请求txtdb, 用于下拉菜单
        $http.get('/txtdb').success(function(result){
            $scope.txtdb = result.txtdb;
        });

        $scope.submit = function (form) {
            // 向服务请求 nrc 的翻译结果
            $http.get('/nrc', {params: form}).success(function(result){
               // 将翻译的结果赋值给 r_google (result_google的缩写)
                $scope.r_nrc = result.translate_result; 
            });

            // 向服务请求 pbt 的翻译结果
            $http.get('/pbt', {params: form}).success(function(result){
                $scope.r_pbt = result.translate_result;
            });

            // 向服务请求 aml 的翻译结果
            $http.get('/aml', {params: form}).success(function(result){
                $scope.r_aml = result.translate_result;
            });

            // 向服务请求 jx 的翻译结果
            $http.get('/jx', {params: form}).success(function(result){
                $scope.r_jx = result.translate_result;
            });

            // 向服务请求 sh 的翻译结果
            $http.get('/sh', {params: form}).success(function(result){
                $scope.r_sh = result.translate_result;
            });

            // 向服务请求 sri 的翻译结果
            $http.get('/sri', {params: form}).success(function(result){
                $scope.r_sri = result.translate_result;
            });

            // 向服务请求 Best 的翻译结果
            $http.get('/best', {params: form}).success(function(result){
                $scope.r_best = result.translate_result;
            });
        }

    }])